//
//  LKNavigationServiceDelegate.h
//  LKNavigationKit
//
//  Created by RD on 2020/9/30.
//  Copyright © 2020 luokuang. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>
#import <LKMapSDK_Base/LKTypes.h>
#import "LKNRouteResponse.h"
#import "LKNRouteProgress.h"
#import "LKNavigationEnums.h"

@class LKNavigationService;

NS_ASSUME_NONNULL_BEGIN

/// 导航服务代理协议
@protocol LKNavigationServiceDelegate <NSObject>

@optional

/**
 * 路线规划成功
 * @param service 导航服务
 * @param response 路线规划响应结果
 */
- (void)navigationService:(LKNavigationService *)service
        didCalculateRoute:(nullable LKNRouteResponse *)response;

/**
 * 路线规划失败
 * @param service 导航服务
 * @param code 路线规划失败状态码
 */
- (void)navigationService:(LKNavigationService *)service
didFailToCalculateRouteWithErrorCode:(LKNRouteResponseCode)code;

/**
 * 选中路线
 * @param service 导航服务
 * @param route 选中的路线
 * @param index 选中路线的索引
 */
- (void)navigationService:(LKNavigationService *)service
           didSelectRoute:(LKNRoute *)route
                    index:(NSUInteger)index;

/**
 * 位置更新
 * @param service 导航服务
 * @param location 位置
 */
- (void)navigationService:(LKNavigationService *)service
        didUpdateLocation:(CLLocation *)location;

/**
 * GPS信号强度更新
 * @param service 导航服务
 * @param signal 信号强度
 */
- (void)navigationService:(LKNavigationService *)service
       didUpdateGPSSignal:(LKNavigationGPSSignal)signal;

/**
 * 路线行驶进度信息更新
 * @param service 导航服务
 * @param progress 路线行驶进度信息
 */
- (void)navigationService:(LKNavigationService *)service
   didUpdateRouteProgress:(LKNRouteProgress *)progress;

/**
 * 机动点信息更新
 * @param service 导航服务
 * @param instruction 机动点信息
 */
- (void)navigationService:(LKNavigationService *)service
didUpdateManeuverInstruction:(LKNManeuverInstruction *)instruction;

/**
 * 车道信息更新
 * @param service 导航服务
 * @param instruction 车道信息
 */
- (void)navigationService:(LKNavigationService *)service
 didUpdateLaneInstruction:(LKNLaneInstruction *)instruction;

/**
 * 隐藏车道信息
 * @param service 导航服务
 */
- (void)navigationServiceDidHideLaneInstruction:(LKNavigationService *)service;

/**
 * 语音播报信息更新
 * @param service 导航服务
 * @param spokenInstruction 语音播报信息
 */
- (void)navigationService:(LKNavigationService *)service
didUpdateSpokenInstruction:(LKNSpokenInstruction *)spokenInstruction;

/**
 * 偏航时是否重新规划路线。返回YES时重新规划路线，返回NO时不重新规划路线，默认：YES
 * @param service 导航服务
 * @return 偏航时是否重新规划路线。返回YES时重新规划路线；返回NO时不重新规划路线
 */
- (BOOL)navigationServiceShouldReroute:(LKNavigationService *)service;

/**
 * 偏航后，将要重新规划路线
 * @param service 导航服务
 */
- (void)navigationServiceWillReroute:(LKNavigationService *)service;

/**
 * 偏航后，已经重新规划路线
 * @param service 导航服务
 * @param response 路线规划响应结果
 */
- (void)navigationService:(LKNavigationService *)service
               didReroute:(nullable LKNRouteResponse *)response;

/**
 * 偏航后，重新规划路线失败
 * @param service 导航服务
 * @param code 重新规划路线失败状态码
 */
- (void)navigationService:(LKNavigationService *)service
didFailToRerouteWithErrorCode:(LKNRouteResponseCode)code;

/**
 * 到达目的地
 * @param service 导航服务
 * @param navigationType 导航类型
 */
- (void)navigationService:(LKNavigationService *)service
didArriveAtDestinationWithNavigationType:(LKNavigationType)navigationType;

@end

NS_ASSUME_NONNULL_END
