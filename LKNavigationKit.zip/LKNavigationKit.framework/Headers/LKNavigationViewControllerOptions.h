//
//  LKNavigationViewControllerOptions.h
//  LKNavigationKit
//
//  Created by RD on 2020/10/9.
//  Copyright © 2020 箩筐. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LKNavigationService.h"

NS_ASSUME_NONNULL_BEGIN

/// 导航视图控制器配置项
@interface LKNavigationViewControllerOptions : NSObject

/// 导航服务
@property (nonatomic, strong) LKNavigationService *navigationService;

@end

NS_ASSUME_NONNULL_END
