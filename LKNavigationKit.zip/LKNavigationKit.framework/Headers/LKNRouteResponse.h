//
//  LKNRouteResponse.h
//  LKNavigationKit
//
//  Created by RD on 2020/11/3.
//  Copyright © 2020 箩筐. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <LKMapSDK_Base/LKLocation.h>
#import "LKNavigationEnums.h"

@class LKNRoute;
@class LKNSegment;
@class LKNLink;

NS_ASSUME_NONNULL_BEGIN

/// 路线规划响应结果
@interface LKNRouteResponse : NSObject

/// 状态码
@property (nonatomic, assign) LKNRouteResponseCode code;

/// 路线
@property (nonatomic, copy) NSArray <LKNRoute *> *routes;

@end

/// 路线
@interface LKNRoute : NSObject

/// 预估通行距离。单位：米
@property (nonatomic, assign) CLLocationDistance distance;

/// 预估通行时间。单位：秒
@property (nonatomic, assign) NSTimeInterval duration;

/// 所有坐标
@property (nonatomic, copy) NSArray <LKLocation *> *coordinates;

/// 所有分段
@property (nonatomic, copy) NSArray <LKNSegment *> *segments;

@end

/// 路线上的路段
@interface LKNSegment : NSObject

/// 预估通行距离。单位：米
@property (nonatomic, assign) CLLocationDistance distance;

/// 预估通行时间。单位：秒
@property (nonatomic, assign) NSTimeInterval duration;

/// 所有坐标
@property (nonatomic, copy) NSArray <LKLocation *> *coordinates;

/// 所有link
@property (nonatomic, copy) NSArray <LKNLink *> *links;

/// 转向图标。转向图标由多个图标叠加而成。
@property (nonatomic, copy) NSArray <NSNumber *> *instructionIconNames;

@end

/// 路段上的link
@interface LKNLink : NSObject

/// 预估通行距离。单位：米
@property (nonatomic, assign) CLLocationDistance distance;

/// 预估通行时间。单位：秒
@property (nonatomic, assign) NSTimeInterval duration;

/// 所有坐标
@property (nonatomic, copy) NSArray <LKLocation *> *coordinates;

/// 道路名称
@property (nonatomic, copy) NSString *name;

/// 道路类型
@property (nonatomic, assign) LKNavigationRoadType roadType;

@end

NS_ASSUME_NONNULL_END
