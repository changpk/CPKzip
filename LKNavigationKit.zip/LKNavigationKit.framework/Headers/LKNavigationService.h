//
//  LKNavigationService.h
//  LKNavigationKit
//
//  Created by RD on 2020/9/30.
//  Copyright © 2020 luokuang. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LKNavigationServiceOptions.h"
#import "LKNavigationServiceDelegate.h"
#import "LKNRoutePlanOptions.h"

NS_ASSUME_NONNULL_BEGIN

/// 导航服务
@interface LKNavigationService : NSObject

/// 代理
@property (nonatomic, weak, nullable) id<LKNavigationServiceDelegate> delegate;

/// 导航服务配置项
@property (nonatomic, strong, readonly) LKNavigationServiceOptions *navigationServiceOptions;

/// 路线规划配置项
@property (nonatomic, strong, readonly, nullable) LKNRoutePlanOptions *routePlanOptions;

/// 模拟导航速度倍率。默认：`LKNavigationSimulationSpeedModeLow`
@property (nonatomic, assign) LKNavigationSimulationSpeedMode simulationSpeedMode;

/// 当前选择的路线
@property (nonatomic, strong, readonly, nullable) LKNRoute *selectedRoute;

/// 当前选择的路线的索引
@property (nonatomic, assign, readonly) NSUInteger selectedRouteIndex;

/// 当前所有路线
@property (nonatomic, copy, readonly, nullable) NSArray <LKNRoute *> *routes;

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;

/**
 * 创建导航服务实例
 * @param options 导航服务配置项
 * @return 导航服务实例
 */
- (instancetype)initWithOptions:(LKNavigationServiceOptions *)options;

/**
 * 规划路线
 * @param options 路线规划配置项
 */
- (void)calculateRouteWithOptions:(LKNRoutePlanOptions *)options;

/**
 * 开始导航服务，路线规划成功后，调用该方法开始导航服务。使用`LKNavigationViewController`时，开发者不需要调用该方法。
 */
- (void)start;

/**
 * 停止导航服务，导航结束后调用该方法停止导航服务。使用`LKNavigationViewController`时，开发者不需要调用该方法。
 */
- (void)stop;

/**
 * 暂停模拟导航
 */
- (void)pause;

/**
 * 恢复模拟导航
 */
- (void)resume;

/**
 * 选择路线
 * @param index 要选择的路线的索引
 * @return 是否选择成功
 */
- (BOOL)selectRouteWithIndex:(NSUInteger)index;

/**
 * 移除所有路线。调用该方法会重置 `routes` = nil，`selectedRoute` =  0，`selectedRoute` = nil
 */
- (void)removeRoutes;

#pragma mark - TTS

/// 是否静音
@property (nonatomic, assign, getter=isMuted) BOOL muted;

/**
 * 使用SDK默认语音合成播报
 * @param spokenInstruction 播报信息类
 */
- (void)speakWithSpokenInstruction:(LKNSpokenInstruction *)spokenInstruction;

/**
 * 停止播报
 */
- (void)stopSpeaking;

/**
 * 打断播报
 */
- (void)interruptSpeaking;

/**
 * 偏航后，播报 ding 提示音
 */
- (void)pauseSpeechAndPlayReroutingDing;

@end

NS_ASSUME_NONNULL_END
