//
//  LKNavigationMapViewDelegate.h
//  LKNavigationKit
//
//  Created by RD on 2020/10/9.
//  Copyright © 2020 箩筐. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LKNRouteResponse.h"

@class LKNavigationMapView;

NS_ASSUME_NONNULL_BEGIN

/// 导航地图视图代理协议
@protocol LKNavigationMapViewDelegate <NSObject>

@optional

/**
 * 选中某条路线
 * 不要在该方法中调用 `LKNavigationMapView` 的 `selectRouteWithIndex:`方法
 * @param navigationMapView 导航地图视图
 * @param route 选中的路线
 * @param index 选中的路线的索引
 */
- (void)navigationMapView:(LKNavigationMapView *)navigationMapView
           didSelectRoute:(LKNRoute *)route
                  atIndex:(NSUInteger)index;

/**
 * 进入锁车状态
 * @param navigationMapView 导航地图视图
 */
- (void)navigationMapViewDidLockUserCourseView:(LKNavigationMapView *)navigationMapView;

/**
 * 进入非锁车状态
 * @param navigationMapView 导航地图视图
 */
- (void)navigationMapViewDidUnlockUserCourseView:(LKNavigationMapView *)navigationMapView;

#pragma mark 地图加载状态

/**
 * 地图开始加载
 *
 * @param navigationMapView 地图
 */
- (void)navigationMapViewWillStartLoadingMap:(LKNavigationMapView *)navigationMapView;

/**
 * 地图样式完成加载
 *
 * @param navigationMapView 地图
 */
- (void)navigationMapViewDidFinishLoadingStyle:(LKNavigationMapView *)navigationMapView;

/**
 * 地图完成加载
 *
 * @param navigationMapView 地图
 */
- (void)navigationMapViewDidFinishLoadingMap:(LKNavigationMapView *)navigationMapView;

/**
 * 地图加载失败
 *
 * @param navigationMapView 地图
 * @param error 失败原因
 */
- (void)navigationMapViewDidFailLoadingMap:(LKNavigationMapView *)navigationMapView withError:(NSError *)error;

/**
 * 地图开始渲染
 */
- (void)navigationMapViewWillStartRenderingMap:(LKNavigationMapView *)navigationMapView;

/**
 * 地图完成渲染
 */
- (void)navigationMapViewDidFinishRenderingMap:(LKNavigationMapView *)navigationMapView fullyRendered:(BOOL)fullyRendered;

/**
 * 地图开始重绘
 *
 * @param navigationMapView 地图
 * @note 该方法调用十分频繁，请不要在该方法中做复杂操作
 */
- (void)navigationMapViewWillStartRenderingFrame:(LKNavigationMapView *)navigationMapView;

/**
 * 地图完成重绘
 *
 * @param navigationMapView 地图
 * @note 该方法调用十分频繁，请不要在该方法中做复杂操作
 */
- (void)navigationMapViewDidFinishRenderingFrame:(LKNavigationMapView *)navigationMapView fullyRendered:(BOOL)fullyRendered;

#pragma mark 地图状态

/**
 * 地图区域即将要改变
 *
 * @param navigationMapView 地图
 * @param animated 是否动画
 */
- (void)navigationMapView:(LKNavigationMapView *)navigationMapView regionWillChangeAnimated:(BOOL)animated;

/**
 * 地图区域即将要改变
 *
 * @param navigationMapView 地图
 * @param animated 是否动画
 * @param reason 改变原因
 *
 * @note 实现该方法后，不再调用`-navigationMapView:regionWillChangeAnimated:`

 */
- (void)navigationMapView:(LKNavigationMapView *)navigationMapView regionWillChangeWithReason:(LKCameraChangeReason)reason animated:(BOOL)animated;

/**
 * 地图区域正在改变
 *
 * @param navigationMapView 地图
 *
 * @note 手势及调用API方法，例如：`-[LKMapView setCamera:animated:]，都会调用该方法
 * @note 该方法可能会在 `-navigationMapViewDidFinishLoadingMap:` 之前被调用
 * @note 由于会频繁调用该方法，所以不要做复杂操作
 */
- (void)navigationMapViewRegionIsChanging:(LKNavigationMapView *)navigationMapView;

/**
 * 地图区域正在改变
 *
 * @param navigationMapView 地图
 * @param reason 改变原因
 *
 * @note 手势及调用API方法，例如：`-[LKMapView setCamera:animated:]，都会调用该方法
 * @note 该方法可能会在 `-navigationMapViewDidFinishLoadingMap:` 之前被调用
 * @note 由于会频繁调用该方法，所以不要做复杂操作
 * @note 实现该方法后，不再调用`-navigationMapViewRegionIsChanging:`
 */
- (void)navigationMapView:(LKNavigationMapView *)navigationMapView regionIsChangingWithReason:(LKCameraChangeReason)reason;

/**
 * 地图区域已经改变
 *
 * @param navigationMapView 地图
 * @param animated 是否动画
 *
 * @note 该方法可能会在 `-navigationMapViewDidFinishLoadingMap:` 之前被调用
 */
- (void)navigationMapView:(LKNavigationMapView *)navigationMapView regionDidChangeAnimated:(BOOL)animated;

/**
 * 地图区域已经改变
 *
 * @param navigationMapView 地图
 * @param animated 是否动画
 * @param reason 改变原因
 *
 * @note 该方法可能会在 `-navigationMapViewDidFinishLoadingMap:` 之前被调用
 * @note 实现该方法后，不再调用`-navigationMapView:regionDidChangeAnimated:`
 */
- (void)navigationMapView:(LKNavigationMapView *)navigationMapView regionDidChangeWithReason:(LKCameraChangeReason)reason animated:(BOOL)animated;

#pragma mark 标注视图

/**
 * 根据标注生成对应的标注视图
 *
 * @param navigationMapView 地图
 * @param annotation 标注
 * @return 标注视图
 */
- (nullable LKAnnotationView *)navigationMapView:(LKNavigationMapView *)navigationMapView viewForAnnotation:(id <LKAnnotation>)annotation;

/**
 * 向地图新添加标注视图时会调用此接口
 *
 * @param navigationMapView 地图
 * @param annotationViews 标注视图数组
 */
- (void)navigationMapView:(LKNavigationMapView *)navigationMapView didAddAnnotationViews:(NSArray<LKAnnotationView *> *)annotationViews;

/**
 * 当点击一个标注视图时会调用此接口
 * 每次点击标注视图都会回调此接口
 *
 * @param navigationMapView 地图
 * @param annotationView 点击的标注视图
 */
- (void)navigationMapView:(LKNavigationMapView *)navigationMapView clickAnnotationView:(LKAnnotationView *)annotationView;

/**
 * 当选中一个标注视图时会调用此接口
 *
 * @param navigationMapView 地图
 * @param annotationView 选中的标注视图
 */
- (void)navigationMapView:(LKNavigationMapView *)navigationMapView didSelectAnnotationView:(LKAnnotationView *)annotationView;

/**
 * 当取消选中一个标注视图时会调用此接口
 *
 * @param navigationMapView 地图
 * @param annotationView 取消选中的标注视图
 */
- (void)navigationMapView:(LKNavigationMapView *)navigationMapView didDeselectAnnotationView:(LKAnnotationView *)annotationView;

/**
 * 拖动标注视图时，若view的状态发生变化时会调用此接口
 *
 * @param navigationMapView 地图
 * @param view 标注视图
 * @param newState 新状态
 * @param oldState 旧状态
 */
- (void)navigationMapView:(LKNavigationMapView *)navigationMapView annotationView:(LKAnnotationView *)view didChangeDragState:(LKAnnotationViewDragState)newState
   fromOldState:(LKAnnotationViewDragState)oldState;

#pragma mark 覆盖物
/**
 * 根据overlay生成对应的Renderer
 * @param navigationMapView 地图
 * @param overlay 指定的overlay
 * @return 生成的覆盖物Renderer
 */
- (nullable LKOverlayRenderer *)navigationMapView:(LKNavigationMapView *)navigationMapView rendererForOverlay:(id <LKOverlay>)overlay;

/**
 * 当navigationMapView新添加overlay renderers时会调用此接口
 *
 * @param navigationMapView 地图
 * @param overlayRenderers 新添加的覆盖物
 */
- (void)navigationMapView:(LKNavigationMapView *)navigationMapView didAddOverlayRenderers:(NSArray<LKOverlayRenderer *> *)overlayRenderers;

/**
 * 点击覆盖物后会调用此接口。目前支持 LKPolylineRenderer（需要同时设置 userInteractionEnabled 为YES）、LKPolygonRenderer、LKCircleRenderer、LKArcRenderer
 *
 * @param navigationMapView 地图
 * @param overlayRenderer 覆盖物view信息
 */
- (void)navigationMapView:(LKNavigationMapView *)navigationMapView clickOverlayRenderer:(LKOverlayRenderer *)overlayRenderer;

#pragma mark 手势事件
/**
 * 单击地图
 *
 * @param navigationMapView 地图
 * @param coordinate 单击处地理坐标
 */
- (void)navigationMapView:(LKNavigationMapView *)navigationMapView onClickForCoordinate:(CLLocationCoordinate2D)coordinate;

/**
 * 双击地图
 *
 * @param navigationMapView 地图
 * @param coordinate 双击处地理坐标
 */
- (void)navigationMapView:(LKNavigationMapView *)navigationMapView onDoubleClickForCoordinate:(CLLocationCoordinate2D)coordinate;

/**
 * 长按地图
 *
 * @param navigationMapView 地图
 * @param coordinate 长按处地理坐标
 */
- (void)navigationMapView:(LKNavigationMapView *)navigationMapView onLongPressForCoordinate:(CLLocationCoordinate2D)coordinate;

#pragma mark 标注弹出框
/**
 * 设置是否允许显示弹出框。默认NO
 *
 * @param navigationMapView 地图
 * @param annotation 标注
 * @return 是否允许显示弹出框
 */
- (BOOL)navigationMapView:(LKNavigationMapView *)navigationMapView annotationCanShowCallout:(id <LKAnnotation>)annotation;

/**
 * 自定义弹出框
 *
 * @param navigationMapView 地图
 * @param annotation 标注
 * @return 弹框视图
 */
- (nullable LKCalloutView *)navigationMapView:(LKNavigationMapView *)navigationMapView calloutViewForAnnotation:(id <LKAnnotation>)annotation;

/**
 * 自定义弹出框的左侧辅助视图
 *
 * 当视图（或子视图）是`UIControl`子类时，点击辅助视图会回调 `-navigationMapView:annotation:calloutAccessoryControlTapped:`方法
 *
 * @param navigationMapView 地图
 * @param annotation 标注
 * @return 左侧辅助视图
 */
- (nullable UIView *)navigationMapView:(LKNavigationMapView *)navigationMapView leftCalloutAccessoryViewForAnnotation:(id <LKAnnotation>)annotation;

/**
 * 自定义弹出框右侧辅助视图
 *
 * 当视图（或子视图）是`UIControl`子类时，点击辅助视图会回调 `-navigationMapView:annotation:calloutAccessoryControlTapped:`方法
 *
 * @param navigationMapView 地图
 * @param annotation 标注
 * @return 右侧辅助视图
 */
- (nullable UIView *)navigationMapView:(LKNavigationMapView *)navigationMapView rightCalloutAccessoryViewForAnnotation:(id <LKAnnotation>)annotation;

/**
 * 当点击标注弹出框左/右侧辅助视图时会调用此方法
 *
 * @note 标注弹出框左或右辅助视图（或子视图）是`UIControl`子类时，将回调此方法
 *
 * @param navigationMapView 地图
 * @param annotation 标注
 * @param control 辅助视图点击事件
 */
- (void)navigationMapView:(LKNavigationMapView *)navigationMapView annotation:(id <LKAnnotation>)annotation calloutAccessoryControlTapped:(UIControl *)control;

/**
 * 当点击标注弹出框时会调用此方法
 *
 * @param navigationMapView 地图
 * @param annotation 标注
 */
- (void)navigationMapView:(LKNavigationMapView *)navigationMapView tapOnCalloutForAnnotation:(id <LKAnnotation>)annotation;

@end

NS_ASSUME_NONNULL_END
