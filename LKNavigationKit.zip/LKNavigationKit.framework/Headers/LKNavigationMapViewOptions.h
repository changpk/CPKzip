//
//  LKNavigationMapViewOptions.h
//  LKNavigationKit
//
//  Created by RD on 2020/10/9.
//  Copyright © 2020 箩筐. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LKNavigationService.h"

NS_ASSUME_NONNULL_BEGIN

/// 导航地图视图配置项
@interface LKNavigationMapViewOptions : NSObject

/// 导航服务
@property (nonatomic, strong) LKNavigationService *navigationService;

@end

NS_ASSUME_NONNULL_END
