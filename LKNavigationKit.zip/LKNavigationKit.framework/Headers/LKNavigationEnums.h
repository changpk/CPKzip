//
//  LKNavigationEnums.h
//  LKNavigationKit
//
//  Created by RD on 2020/11/6.
//  Copyright © 2020 箩筐. All rights reserved.
//

#ifndef LKNavigationEnums_h
#define LKNavigationEnums_h

/// 路线规划状态码
typedef NS_ENUM(NSInteger, LKNRouteResponseCode) {
    
    LKNRouteResponseCodeErrorOther              = -1,   ///< 其他错误
    LKNRouteResponseCodeSuccess                 = 0,    ///< 成功
    LKNRouteResponseCodeErrorInvalidCoordinate  = 1,    ///< 起点或终点坐标无效
    LKNRouteResponseCodeErrorNotFoundRoutes     = 2,    ///< 没有可用路线
    LKNRouteResponseCodeErrorNetworkConnection  = 3,    ///< 网络连接失败
    LKNRouteResponseCodeErrorServer             = 4,    ///< 服务器错误，5xx
    LKNRouteResponseCodeErrorNotFound           = 5,    ///< 404
};

/// 语音播报失败状态码
typedef NS_ENUM(NSUInteger, LKNSpeechErrorCode) {
    LKNSpeechErrorCodeNoData,
    LKNSpeechErrorCodeUnableToControlAudio,
    LKNSpeechErrorCodeUnableToInitializePlayer,
};

/// GPS信号强度。卫星、基站、wifi综合定位结果。
typedef NS_ENUM(NSUInteger, LKNavigationGPSSignal) {
    LKNavigationGPSSignalGood = 0, ///< 信号强
    LKNavigationGPSSignalPoor = 1, ///< 信号弱
};

/// 路线规划类型
typedef NS_ENUM(NSUInteger, LKNRoutePlanType) {
    LKNRoutePlanTypeDriving = 0, ///< 驾车
    LKNRoutePlanTypeTruck   = 1, ///< 货车
};

/// 导航类型
typedef NS_ENUM(NSUInteger, LKNavigationType) {
    LKNavigationTypeGPS         = 0, ///< 实时导航
    LKNavigationTypeSimulation  = 1, ///< 模拟导航
};

/// 模拟导航速度倍率
typedef NS_ENUM(NSUInteger, LKNavigationSimulationSpeedMode) {
    LKNavigationSimulationSpeedModeLow      = 0, ///< 低速，60km/h
    LKNavigationSimulationSpeedModeMedium   = 1, ///< 中速，90km/h
    LKNavigationSimulationSpeedModeHigh     = 2, ///< 高速，150km/h
};

/// 方向诱导图标ID
typedef NS_ENUM(NSUInteger, LKNavigationManeuverIconID) {
    LKNavigationManeuverIconIDNone                 = 0, ///< 无，默认显示直行
    LKNavigationManeuverIconIDDestination          = 1, ///< 终点
    LKNavigationManeuverIconIDTurnLeft             = 2, ///< 左转
    LKNavigationManeuverIconIDTurnLeftSlight       = 3, ///< 明显左前
    LKNavigationManeuverIconIDTurnLeftSlighter     = 4, ///< 较为左前
    LKNavigationManeuverIconIDTurnLeftSlightest    = 5, ///< 稍微左前
    LKNavigationManeuverIconIDTurnLeftSharp        = 6, ///< 稍微左后
    LKNavigationManeuverIconIDTurnLeftSharper      = 7, ///< 较为左后
    LKNavigationManeuverIconIDTurnLeftSharpest     = 8, ///< 明显左后
    LKNavigationManeuverIconIDTurnRight            = 9, ///< 右转
    
    LKNavigationManeuverIconIDTurnRightSlightest           = 10, ///< 稍微右前
    LKNavigationManeuverIconIDTurnRightSlighter            = 11, ///< 较为右前
    LKNavigationManeuverIconIDTurnRightSlight              = 12, ///< 明显右前
    LKNavigationManeuverIconIDTurnRightSharp               = 13, ///< 稍微右后
    LKNavigationManeuverIconIDTurnRightSharper             = 14, ///< 较为右后
    LKNavigationManeuverIconIDTurnRightSharpest            = 15, ///< 明显右后
    LKNavigationManeuverIconIDStraight                     = 16, ///< 直行
    LKNavigationManeuverIconIDTurnAroundAlongTheSameRoad   = 17, ///< 相同道路调头
    LKNavigationManeuverIconIDTurnAround                   = 18, ///< 非相同道路调头，调头道路无分歧
    LKNavigationManeuverIconIDTurnAroundEnterLeftRoad      = 19, ///< 非相同道路调头，调头道路有一个分歧道路，并且进入左侧道路
    
    LKNavigationManeuverIconIDTurnAroundEnterRightRoad     = 20, ///< 非相同道路调头，调头道路有一个分歧道路，并且进入右侧道路
    LKNavigationManeuverIconIDStraightBackground           = 21, ///< 直行的背景
    LKNavigationManeuverIconIDTurnRightSlightestBackground = 22, ///< 稍微右前的背景
    LKNavigationManeuverIconIDTurnRightSlighterBackground  = 23, ///< 较为右前的背景
    LKNavigationManeuverIconIDTurnRightSlightBackground    = 24, ///< 明显右前的背景
    LKNavigationManeuverIconIDTurnRightBackground          = 25, ///< 右转的背景
    LKNavigationManeuverIconIDTurnRightSharpBackground     = 26, ///< 稍微右后的背景
    LKNavigationManeuverIconIDTurnRightSharperBackground   = 27, ///< 较为右后的背景
    LKNavigationManeuverIconIDTurnRightSharpestBackground  = 28, ///< 明显右后的背景
    LKNavigationManeuverIconIDTurnLeftSharpestBackground   = 29, ///< 明显左后的背景
    
    LKNavigationManeuverIconIDTurnLeftSharperBackground    = 30, ///< 较为左后的背景
    LKNavigationManeuverIconIDTurnLeftSharpBackground      = 31, ///< 稍微左后的背景
    LKNavigationManeuverIconIDTurnLeftBackground           = 32, ///< 左转的背景
    LKNavigationManeuverIconIDTurnLeftSlightBackground     = 33, ///< 明显左前的背景
    LKNavigationManeuverIconIDTurnLeftSlighterBackground   = 34, ///< 较为左前的背景
    LKNavigationManeuverIconIDTurnLeftSlightestBackground  = 35, ///< 稍微左前的背景
    LKNavigationManeuverIconIDDestinationOnRoundabout      = 36, ///< 进入环岛，目的地或途经点在环岛上
    LKNavigationManeuverIconIDStartFromRoundaboutLeaveOnRightSharply   = 37, ///< 起点在小环岛上，右后方出环岛
    LKNavigationManeuverIconIDStartFromRoundaboutLeaveOnRight          = 38, ///< 起点在小环岛上，右转出环岛
    LKNavigationManeuverIconIDStartFromRoundaboutLeaveOnRightSlightly  = 39, ///< 起点在小环岛上，右前方出环岛
    
    LKNavigationManeuverIconIDStartFromRoundaboutLeaveOnStraightly     = 40, ///< 起点在小环岛上，直行出环岛
    LKNavigationManeuverIconIDStartFromRoundaboutLeaveOnLeftSlightly   = 41, ///< 起点在小环岛上，左前方出环岛
    LKNavigationManeuverIconIDStartFromRoundaboutLeaveOnLeft           = 42, ///< 起点在小环岛上，左转出环岛
    LKNavigationManeuverIconIDStartFromRoundaboutLeaveOnLeftSharply    = 43, ///< 起点在小环岛上，左后方出环岛
    LKNavigationManeuverIconIDStartFromRoundaboutLeaveOnUTurn          = 44, ///< 起点在小环岛上，调头出环岛
    LKNavigationManeuverIconIDRoundaboutLeaveOnRightSharply            = 45, ///< 起点不在小环岛上，右后方出环岛
    LKNavigationManeuverIconIDRoundaboutLeaveOnRight                   = 46, ///< 起点不在小环岛上，右转出环岛
    LKNavigationManeuverIconIDRoundaboutLeaveOnRightSlightly           = 47, ///< 起点不在小环岛上，右前方出环岛
    LKNavigationManeuverIconIDRoundaboutLeaveOnStraightly              = 48, ///< 起点不在小环岛上，直行出环岛
    LKNavigationManeuverIconIDRoundaboutLeaveOnLeftSlightly            = 49, ///< 起点不在小环岛上，左前方出环岛
    
    LKNavigationManeuverIconIDRoundaboutLeaveOnLeft        = 50, ///< 起点不在小环岛上，左转出环岛
    LKNavigationManeuverIconIDRoundaboutLeaveOnLeftSharply = 51, ///< 起点不在小环岛上，左后方出环岛
    LKNavigationManeuverIconIDRoundaboutLeaveOnUTurn       = 52, ///< 起点不在小环岛上，调头出环岛
    LKNavigationManeuverIconIDRoundaboutLeaveOnFirst       = 53, ///< 起点不在大环岛上，出口 1
    LKNavigationManeuverIconIDRoundaboutLeaveOnSecond      = 54, ///< 起点不在大环岛上，出口 2
    LKNavigationManeuverIconIDRoundaboutLeaveOnThird       = 55, ///< 起点不在大环岛上，出口 3
    LKNavigationManeuverIconIDRoundaboutLeaveOnFourth      = 56, ///< 起点不在大环岛上，出口 4
    LKNavigationManeuverIconIDRoundaboutLeaveOnFifth       = 57, ///< 起点不在大环岛上，出口 5
    LKNavigationManeuverIconIDRoundaboutLeaveOnSixth       = 58, ///< 起点不在大环岛上，出口 6
    LKNavigationManeuverIconIDRoundaboutLeaveOnSeventh     = 59, ///< 起点不在大环岛上，出口 7
    
    LKNavigationManeuverIconIDRoundaboutLeaveOnEighth      = 60, ///< 起点不在大环岛上，出口 8
    LKNavigationManeuverIconIDRoundaboutLeaveOnNinth       = 61, ///< 起点不在大环岛上，出口 9
    LKNavigationManeuverIconIDRoundaboutLeaveOnTenth       = 62, ///< 起点不在大环岛上，出口 10
    LKNavigationManeuverIconIDRoundaboutLeaveOnEleventh    = 63, ///< 起点不在大环岛上，出口 11
    LKNavigationManeuverIconIDRoundaboutLeaveOnTwelfth     = 64, ///< 起点不在大环岛上，出口 12
    LKNavigationManeuverIconIDRoundaboutLeaveOnThirteenth  = 65, ///< 起点不在大环岛上，出口 13
    LKNavigationManeuverIconIDRoundaboutLeaveOnFourteenth  = 66, ///< 起点不在大环岛上，出口 14
    LKNavigationManeuverIconIDRoundaboutLeaveOnFifteenth   = 67, ///< 起点不在大环岛上，出口 15
    LKNavigationManeuverIconIDRoundaboutLeaveOnSixteenth   = 68, ///< 起点不在大环岛上，出口 16
    LKNavigationManeuverIconIDTurnLeftAtTheEndOfRoad        = 69, ///< 道路尽头左转
    
    LKNavigationManeuverIconIDTurnRightAtTheEndOfRoad  = 70, ///< 道路尽头右转
    LKNavigationManeuverIconIDWaypoint                 = 71, ///< 途经点
    LKNavigationManeuverIconIDTunnel                   = 72, ///< 隧道
    LKNavigationManeuverIconIDTollStation              = 73, ///< 收费站
};

/// 车道图标ID。以下注释：车道方向 + 行进方向。
typedef NS_ENUM(NSUInteger, LKNavigationLaneIconID) {
    LKNavigationLaneIconIDStraight_None = 1, ///< 直行 + 无
    LKNavigationLaneIconIDTurnRight_None = 2, ///< 右转 + 无
    LKNavigationLaneIconIDTurnAround_None = 4, ///< 调头 + 无
    LKNavigationLaneIconIDTurnLeft_None = 8, ///< 左转 + 无
    LKNavigationLaneIconIDStraightAndTurnRight_None = 3, ///< 直行、右转 + 无
    LKNavigationLaneIconIDStraightAndTurnAround_None = 5, ///< 直行、调头 + 无
    LKNavigationLaneIconIDStraightAndTurnLeft_None = 9, ///< 直行、左转 + 无
    LKNavigationLaneIconIDTurnRightAndTurnAround_None = 6, ///< 右转、调头 + 无
    LKNavigationLaneIconIDTurnRightAndTurnLeft_None = 10, ///< 右转、左转 + 无
    LKNavigationLaneIconIDTurnAroundAndTurnLeft_None = 12, ///< 调头、左转 + 无
    LKNavigationLaneIconIDStraightAndTurnRightAndTurnAround_None = 7, ///< 直行、右转、调头 + 无
    LKNavigationLaneIconIDStraightAndTurnRightAndTurnLeft_None = 11, ///< 直行、右转、左转 + 无
    LKNavigationLaneIconIDStraightAndTurnAroundAndTurnLeft_None = 13, ///< 直行、调头、左转 + 无
    LKNavigationLaneIconIDTurnRightAndTurnAroundAndTurnLeft_None = 14, ///<右转、调头、左转 + 无
    LKNavigationLaneIconIDStraightAndTurnRightAndTurnAroundAndTurnLeft_None = 15, ///< 直行、右转、调头、左转 + 无
    LKNavigationLaneIconIDStraight_Straight = 17, ///< 直行 + 直行
    LKNavigationLaneIconIDTurnRight_TurnRight = 34, ///< 右转 + 右转
    LKNavigationLaneIconIDTurnAround_TurnAround = 68, ///< 调头 + 调头
    LKNavigationLaneIconIDTurnLeft_TurnLeft = 136, ///< 左转 + 左转
    LKNavigationLaneIconIDStraightAndTurnRight_Straight = 19, ///< 直行、右转 + 直行
    LKNavigationLaneIconIDStraightAndTurnRight_TurnRight = 35, ///< 直行、右转 + 右转
    LKNavigationLaneIconIDStraightAndTurnAround_Straight = 21, ///< 直行、调头 + 直行
    LKNavigationLaneIconIDStraightAndTurnAround_TurnAround = 69, ///< 直行、调头 + 直行
    LKNavigationLaneIconIDStraightAndTurnLeft_Straight = 25, ///< 直行、左转 + 直行
    LKNavigationLaneIconIDStraightAndTurnLeft_TurnLeft = 137, ///< 直行、左转 + 左转
    LKNavigationLaneIconIDTurnRightAndTurnAround_TurnRight = 38, ///< 右转、调头 + 右转
    LKNavigationLaneIconIDTurnRightAndTurnAround_TurnAround = 70, ///< 右转、调头 + 调头
    LKNavigationLaneIconIDTurnRightAndTurnLeft_TurnRight = 42, ///< 右转、左转 + 右转
    LKNavigationLaneIconIDTurnRightAndTurnLeft_TurnLeft = 138, ///< 右转、左转 + 左转
    LKNavigationLaneIconIDTurnAroundAndTurnLeft_TurnAround = 76, ///< 调头、左转 + 调头
    LKNavigationLaneIconIDTurnAroundAndTurnLeft_TurnLeft = 140, ///< 调头、左转 + 左转
    LKNavigationLaneIconIDStraightAndTurnRightAndTurnAround_Straight = 23, ///< 直行、右转、调头 + 直行
    LKNavigationLaneIconIDStraightAndTurnRightAndTurnAround_TurnRight = 39, ///< 直行、右转、调头 + 右转
    LKNavigationLaneIconIDStraightAndTurnRightAndTurnAround_TurnAround = 71, ///< 直行、右转、调头 + 调头
    LKNavigationLaneIconIDStraightAndTurnRightAndTurnLeft_Straight = 27, ///< 直行、右转、左转 + 直行
    LKNavigationLaneIconIDStraightAndTurnRightAndTurnLeft_TurnRight = 43, ///< 直行、右转、左转 + 右转
    LKNavigationLaneIconIDStraightAndTurnRightAndTurnLeft_TurnLeft = 139, ///< 直行、右转、左转 + 左转
    LKNavigationLaneIconIDStraightAndTurnAroundAndTurnLeft_Straight = 29, ///< 直行、调头、左转 + 直行
    LKNavigationLaneIconIDStraightAndTurnAroundAndTurnLeft_TurnAround = 77, ///< 直行、调头、左转 + 调头
    LKNavigationLaneIconIDStraightAndTurnAroundAndTurnLeft_TurnLeft = 141, ///< 直行、调头、左转 + 左转
    LKNavigationLaneIconIDTurnRightAndTurnAroundAndTurnLeft_TurnRight = 46, ///< 右转、调头、左转 + 右转
    LKNavigationLaneIconIDTurnRightAndTurnAroundAndTurnLeft_TurnAround = 78, ///< 右转、调头、左转 + 调头
    LKNavigationLaneIconIDTurnRightAndTurnAroundAndTurnLeft_TurnLeft = 142, ///< 右转、调头、左转 + 左转
    LKNavigationLaneIconIDStraightAndTurnRightAndTurnAroundAndTurnLeft_Straight = 31, ///< 直行、右转、调头、左转 + 直行
    LKNavigationLaneIconIDStraightAndTurnRightAndTurnAroundAndTurnLeft_TurnRight = 47, ///< 直行、右转、调头、左转 + 右转
    LKNavigationLaneIconIDStraightAndTurnRightAndTurnAroundAndTurnLeft_TurnAround = 79, ///< 直行、右转、调头、左转 + 调头
    LKNavigationLaneIconIDStraightAndTurnRightAndTurnAroundAndTurnLeft_TurnLeft = 143, ///< 直行、右转、调头、左转 + 左转
};

/// 道路类型
// TODO:
typedef NS_ENUM(NSUInteger, LKNavigationRoadType) {
    LKNavigationRoadTypeHighWay = 0,                   ///<  高速公路
    LKNavigationRoadTypeNationalRoad = 1,              ///<  国道
    LKNavigationRoadTypeProvincialRoad = 2,            ///<  省道
    LKNavigationRoadTypeCountyRoad = 3,                ///<  县道
    LKNavigationRoadTypeVillageRoad,                   ///<  乡公路
    LKNavigationRoadTypeCountyInternalRoad,            ///<  县乡村内部道路
    LKNavigationRoadTypeMainStreet,                    ///<  主要大街、城市快速道
    LKNavigationRoadTypeMainRoad,                      ///<  主要道路
    LKNavigationRoadTypeMinorRoad,                     ///<  次要道路
    LKNavigationRoadTypeNormalRoad,                    ///<  普通道路
    LKNavigationRoadTypeNotNaviRoad,                   ///<  非导航道路
};

/// 自车位置跟随模式
typedef NS_ENUM(NSUInteger, LKNavigationUserCourseTrackingMode) {
    LKNavigationUserCourseTrackingModeFollow,               ///<  地图跟随自车位置，地图北向上
    LKNavigationUserCourseTrackingModeFollowWithHeading,    ///< 地图跟随自车位置和方向
    LKNavigationUserCourseTrackingModeFollowWithHeading3D,  ///< 地图跟随自车位置和方向，地图展示为3D模式
};

/// 规划路线的策略
typedef NS_ENUM(NSUInteger, LKNavigationRouteTacticsType) {
    LKNavigationRouteTacticsTypeDefault         = 0, ///< 默认策略（速度优先+躲避拥堵+距离较短）
    LKNavigationRouteTacticsTypeAvoidHighway    = 1, ///< 不走高速
    LKNavigationRouteTacticsTypeHighwayFirst    = 2, ///< 优先高速
    LKNavigationRouteTacticsTypeShortest        = 3, ///< 距离最短
};

/// 导航视图控制器消失原因
typedef NS_ENUM(NSUInteger, LKNavigationViewControllerDismissReason) {
    LKNavigationViewControllerDismissReasonDidArriveDestination,    ///< 到达目的地
    LKNavigationViewControllerDismissReasonDidTapCancelButton,      ///< 点击退出导航按钮
};

#endif /* LKNavigationEnums_h */
