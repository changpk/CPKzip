//
//  main.m
//  LKNavigationKit
//
//  Created by x670990709@126.com on 06/15/2022.
//  Copyright (c) 2022 x670990709@126.com. All rights reserved.
//

@import UIKit;
#import "LKNAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([LKNAppDelegate class]));
    }
}
