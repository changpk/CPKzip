//
//  LKNAppDelegate.h
//  LKNavigationKit
//
//  Created by x670990709@126.com on 06/15/2022.
//  Copyright (c) 2022 x670990709@126.com. All rights reserved.
//

@import UIKit;

@interface LKNAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
