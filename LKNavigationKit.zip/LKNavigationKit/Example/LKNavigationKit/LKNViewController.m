//
//  LKNViewController.m
//  LKNavigationKit
//
//  Created by x670990709@126.com on 06/15/2022.
//  Copyright (c) 2022 x670990709@126.com. All rights reserved.
//

#import "LKNViewController.h"

@interface LKNViewController ()

@end

@implementation LKNViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
