# LKNavigationKit

## 箩筐地图 iOS 导航SDK（官方）
### iOS导航SDK是一套基于iOS9.0及以上版本的导航应用工具集。您可以使用SDK提供的导航UI组件快速集成导航功能。或者使用SDK提供的核心组件，然后自定义UI界面。

[![CI Status](https://img.shields.io/travis/LuokuangLBS/LKMapSDK_Map.svg?style=flat)](https://travis-ci.org/LuokuangLBS/LKMapSDK_Map)
[![Version](https://img.shields.io/cocoapods/v/LKMapSDK_Map.svg?style=flat)](https://cocoapods.org/pods/LKMapSDK_Map)
[![License](https://img.shields.io/cocoapods/l/LKMapSDK_Map.svg?style=flat)](https://cocoapods.org/pods/LKMapSDK_Map)
[![Platform](https://img.shields.io/cocoapods/p/LKMapSDK_Map.svg?style=flat)](https://cocoapods.org/pods/LKMapSDK_Map)

## 示例

克隆工程后，运行 `pod install` 

## 系统

iOS 9.0及以上系统

## 安装

LKNavigationKit 支持 [CocoaPods](https://cocoapods.org) 安装。
将以下命令添加到你的 Podfile 文件中：

```ruby
pod 'LKNavigationKit'
```

## 作者

 箩筐地图开放平台, LuokuangLBS, haofp@luokung.com

## 许可

LKNavigationKit is available under the MIT license. See the LICENSE file for more info.
