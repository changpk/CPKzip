//
//  LKNRoutePlanOptions.h
//  LKNavigationKit
//
//  Created by RD on 2020/9/30.
//  Copyright © 2020 luokuang. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LKNRouteRequest.h"
#import "LKNavigationEnums.h"

NS_ASSUME_NONNULL_BEGIN

/// 路线规划配置项
@interface LKNRoutePlanOptions : NSObject <NSSecureCoding, NSCopying>

/// 路线规划类型。默认：`LKRoutePlanTypeDriving`
@property (nonatomic, assign) LKNRoutePlanType type;

/// 路线规划请求报文
@property (nonatomic, strong) LKNRouteRequest *request;

@end

NS_ASSUME_NONNULL_END
