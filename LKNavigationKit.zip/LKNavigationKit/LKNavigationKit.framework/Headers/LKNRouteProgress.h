//
//  LKNRouteProgress.h
//  LKNavigationKit
//
//  Created by RD on 2020/11/6.
//  Copyright © 2020 箩筐. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>
#import "LKNavigationEnums.h"

NS_ASSUME_NONNULL_BEGIN
/// 导航实时信息
@interface LKNRouteProgress : NSObject

/// 导航类型
@property (nonatomic, assign) LKNavigationType navigationType;

/// 当前道路名称
@property (nonatomic, copy) NSString *currentRoadName;

/// 之后一个道路名称
@property (nonatomic, copy) NSString *upcomingRoadName;

/// 视觉诱导图标名称
@property (nonatomic, assign) LKNavigationManeuverIconID instructionIconID;

/// 路线剩余距离。单位：米
@property (nonatomic, assign) CLLocationDistance routeDistanceRemaining;

/// 路线剩余时间。单位：秒
@property (nonatomic, assign) NSTimeInterval routeDurationRemaining;

/// 路段剩余距离。单位：米
@property (nonatomic, assign) CLLocationDistance segmentDistanceRemaining;

/// 路段剩余时间。单位：秒
@property (nonatomic, assign) NSTimeInterval segmentDurationRemaining;

@end

/// 机动点实时信息
@interface LKNManeuverInstruction : NSObject

/// 一组机动点图标ID。元素类型 `LKNavigationManeuverIconID`
@property (nonatomic, copy) NSArray <NSNumber *> *maneuverIconIDs;

@end

/// 车道实时信息
@interface LKNLaneInstruction : NSObject

/// 一组机动点图标ID。元素类型 `LKNavigationLaneIconID`
@property (nonatomic, copy) NSArray <NSNumber *> *laneIconIDs;

@end

/// 语音诱导文言类
@interface LKNSpokenInstruction : NSObject

/// 诱导文言
@property (nonatomic, copy, nullable) NSString *text;

@end

NS_ASSUME_NONNULL_END
