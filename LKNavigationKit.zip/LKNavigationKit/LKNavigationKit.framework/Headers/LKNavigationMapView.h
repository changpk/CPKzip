//
//  LKNavigaitonMapView.h
//  LKNavigationKit
//
//  Created by RD on 2020/10/9.
//  Copyright © 2020 箩筐. All rights reserved.
//

#import <LKMapSDK_Map/LKMapSDK_Map.h>
#import "LKNavigationMapViewOptions.h"
#import "LKNavigationMapViewDelegate.h"

NS_ASSUME_NONNULL_BEGIN

/// 导航地图视图
@interface LKNavigationMapView : LKMapView

/// 导航地图视图代理
@property (nonatomic, weak, nullable) id<LKNavigationMapViewDelegate> navigationMapViewDelegate;

/// 导航地图视图配置项
@property (nonatomic, strong, readonly) LKNavigationMapViewOptions *options;

/// 起点标注
@property (nonatomic, strong, readonly, nullable) LKPointAnnotation *originAnnotation;

/// 终点标注
@property (nonatomic, strong, readonly, nullable) LKPointAnnotation *destinationAnnotation;

/// 途经点标注数组
@property (nonatomic, strong, readonly) NSMutableArray <LKPointAnnotation *> *waypointAnnotations;

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;
- (instancetype)initWithFrame:(CGRect)frame NS_UNAVAILABLE;
- (instancetype)initWithCoder:(NSCoder *)coder NS_UNAVAILABLE;

/**
 * 创建导航地图视图实例
 * @param options 导航地图视图配置项
 * @return 导航地图视图实例
 */
- (instancetype)initWithOptions:(LKNavigationMapViewOptions *)options;

/**
 * 创建导航地图视图实例
 * @param frame frame
 * @param options 导航地图视图配置项
 * @return 导航地图视图实例
 */
- (instancetype)initWithFrame:(CGRect)frame options:(LKNavigationMapViewOptions *)options;

/**
 * 添加路线
 */
- (void)addRoutes;

/**
 * 移除路线
 */
- (void)removeRoutes;

/**
 * 路线全览
 * @param insets 边距
 */
- (void)showRoutesWithEdgePadding:(UIEdgeInsets)insets;

/**
 * 选中路线
 * @param index 路线的索引
 * @return 是否选中成功
 */
- (BOOL)selectRouteWithIndex:(NSUInteger)index;

/**
 * 添加起点标注
 */
- (void)addOriginAnnotation;

/**
 * 移除起点标注
 */
- (void)removeOriginAnnotation;

/**
 * 添加途经点标注
 */
- (void)addWaypointAnnotations;

/**
 * 移除途经点标注
 */
- (void)removeWaypointAnnotations;

/**
 * 添加终点标注
 */
- (void)addDestinationAnnotation;

/**
 * 移除终点标注
 */
- (void)removeDestinationAnnotation;

/**
 * 添加起点虚线（原始起点与路线起点的连线）
 */
- (void)addOriginDashLine;

/**
 * 移除起点虚线（原始起点与路线起点的连线）
 */
- (void)removeOriginDashLine;

/**
 * 添加终点虚线（原始终点与路线终点的连线）
 */
- (void)addDestinationDashLine;

/**
 * 移除终点虚线（原始终点与路线终点的连线）
 */
- (void)removeDestinationDashLine;

/**
 * 添加用户位置与终点的连线
 */
- (void)addStraightLine;

/**
 * 移除用户位置与终点的连线
 */
- (void)removeStraightLine;

@end

NS_ASSUME_NONNULL_END
