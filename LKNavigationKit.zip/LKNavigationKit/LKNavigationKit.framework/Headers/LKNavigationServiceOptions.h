//
//  LKNavigationServiceOptions.h
//  LKNavigationKit
//
//  Created by RD on 2020/9/30.
//  Copyright © 2020 luokuang. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LKNavigationEnums.h"

NS_ASSUME_NONNULL_BEGIN

/// 导航服务配置项
@interface LKNavigationServiceOptions : NSObject <NSSecureCoding, NSCopying>

/// 导航类型。默认：`LKNavigationTypeGPS`
@property (nonatomic, assign) LKNavigationType navigationType;

/// 模拟导航速度倍率。默认：`LKNavigationSimulationSpeedModeLow`
@property (nonatomic, assign) LKNavigationSimulationSpeedMode simulationSpeedMode;

@end

NS_ASSUME_NONNULL_END
