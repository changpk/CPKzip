//
//  LKNavigationViewControllerDelegate.h
//  LKNavigationKit
//
//  Created by RD on 2020/10/9.
//  Copyright © 2020 箩筐. All rights reserved.
//

#import <Foundation/Foundation.h>

@class LKNavigationViewController;

NS_ASSUME_NONNULL_BEGIN

/// 导航视图控制器代理协议
@protocol LKNavigationViewControllerDelegate <NSObject>

@optional

/**
 * 到达目的地时，是否允许视图控制器消失，默认  `NO`。
 * @param controller 视图控制器
 * @return 是否允许视图控制器消失，默认  `NO`
 */
- (BOOL)navigationViewControllerShouldDismiss:(LKNavigationViewController *)controller;

/**
 * 视图控制器将要消失
 * @param controller 视图控制器
 * @param reason 消失原因
 */
- (void)navigationViewController:(LKNavigationViewController *)controller
           willDismissWithReason:(LKNavigationViewControllerDismissReason)reason;

/**
 * 视图控制器已经消失
 * @param controller 视图控制器
 * @param reason 消失原因
 */
- (void)navigationViewController:(LKNavigationViewController *)controller
            didDismissWithReason:(LKNavigationViewControllerDismissReason)reason;

@end

NS_ASSUME_NONNULL_END
