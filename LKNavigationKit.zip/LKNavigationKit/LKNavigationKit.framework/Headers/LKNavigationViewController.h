//
//  LKNavigationViewController.h
//  LKNavigationKit
//
//  Created by RD on 2020/10/9.
//  Copyright © 2020 箩筐. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LKNavigationViewControllerOptions.h"
#import "LKNavigationViewControllerDelegate.h"

NS_ASSUME_NONNULL_BEGIN

/// 导航视图控制器
@interface LKNavigationViewController : UIViewController

/// 代理
@property (nonatomic, weak, nullable) id<LKNavigationViewControllerDelegate> delegate;

/// 导航视图控制器配置项
@property (nonatomic, strong, readonly) LKNavigationViewControllerOptions *options;

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;
- (instancetype)initWithCoder:(NSCoder *)coder NS_UNAVAILABLE;
- (instancetype)initWithNibName:(nullable NSString *)nibNameOrNil bundle:(nullable NSBundle *)nibBundleOrNil NS_UNAVAILABLE;

/**
 * 创建导航视图控制器实例
 * @param options 导航视图控制器配置项
 * @return 导航视图控制器实例
 */
- (instancetype)initWithOptions:(nullable LKNavigationViewControllerOptions *)options;

@end

NS_ASSUME_NONNULL_END
