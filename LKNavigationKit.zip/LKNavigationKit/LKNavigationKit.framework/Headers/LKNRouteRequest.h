//
//  LKNRouteRequest.h
//  LKNavigationKit
//
//  Created by RD on 2020/11/3.
//  Copyright © 2020 箩筐. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>
#import <LKMapSDK_Base/LKLocation.h>
#import "LKNavigationEnums.h"

NS_ASSUME_NONNULL_BEGIN

/// 路线规划请求
@interface LKNRouteRequest : NSObject

/// 起点坐标
@property (nonatomic, assign) CLLocationCoordinate2D origin;

/// 终点坐标
@property (nonatomic, assign) CLLocationCoordinate2D destination;

/// 途经点坐标
@property (nonatomic, copy) NSArray <LKLocation *> *waypoints;

/// 策略类型。默认 LKNavigationRouteTacticsTypeDefault
@property (nonatomic, assign) LKNavigationRouteTacticsType tacticsType;

@end

NS_ASSUME_NONNULL_END
