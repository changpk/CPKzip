//
//  LKNavigationUtil.h
//  LKNavigationKit
//
//  Created by RD on 2020/11/7.
//  Copyright © 2020 箩筐. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

NS_ASSUME_NONNULL_BEGIN

/// 导航工具类
@interface LKNavigationUtil : NSObject

/**
 * 根据一组ID，获取机动点图标
 * @param IDs 一组ID
 * @return 机动点图标
 */
+ (nullable UIImage *)maneuverIconWithIDs:(NSArray <NSNumber *> *)IDs;

/**
 * 根据ID获取机动点图标
 * @param ID 图标ID，LKNavigationManeuverIconID 类型
 * @return 机动点图标
 */
+ (nullable UIImage *)maneuverIconWithID:(NSNumber *)ID;

/**
 * 根据ID获取车道图标
 * @param ID 图标ID，LKNavigationLaneIconID 类型
 * @return 车道图标
 */
+ (nullable UIImage *)laneIconWithID:(NSNumber *)ID;

/**
 * 将浮点型距离值格式化成字符串。超过1000米，简化为公里
 * @param distance 距离。单位：米
 * @return 格式化后的字符串
 */
+ (nullable NSString *)formatDistance:(CLLocationDistance)distance;

/**
 * 将浮点型时间值格式化成字符串。超过60分钟，简化为小时
 * @param duration 时间。单位：秒
 * @return 格式化后的字符串
 */
+ (nullable NSString *)formatDuration:(NSTimeInterval)duration;

@end

NS_ASSUME_NONNULL_END
